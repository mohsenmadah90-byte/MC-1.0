import { world, EntityComponentTypes, EquipmentSlot } from "@minecraft/server";

import { CashUtils } from "./CashUtils";


export class ItemUtils{

    /**
     * Spawns items in the world at a specified location, respecting max stack size.
     * @param {ItemStack} itemStack - The ItemStack object to spawn.
     * @param {number} amount - The amount of items to spawn.
     * @param {Vector3} location - The location (Vector3) where items should be spawned.
     * @param {Dimension} dimension - The Minecraft dimension object to interact with the game.
     */
    static spawnItems(itemStack, amount, location, dimension) {
        const maxAmount = itemStack.maxAmount;
        let remainingAmount = amount;

        while (remainingAmount > 0) {
            const spawnAmount = Math.min(maxAmount, remainingAmount);

            const itemToSpawn = itemStack.clone();
            itemToSpawn.amount = spawnAmount;

            dimension.spawnItem(itemToSpawn, location);

            remainingAmount -= spawnAmount;
        }
    }

    /**
     * Get the total amount of items in the player's inventory that match the given itemStack.
     * 
     * @param {Player} player - The player whose inventory is to be checked.
     * @param {ItemStack} itemStack - The item stack to match against items in the inventory.
     * @returns {number} The total count of matching items in the player's inventory.
     */
    static getAllSameItems(player, itemStack) {
        let totalAmount = 0;
        let { container, inventorySize: length } = player.getComponent(EntityComponentTypes.Inventory);
        
        for (let i = 0; i < length; i++) {
            const item = container.getItem(i);
            if(item === null || item === undefined) continue;
            if(!this.compareItemStacks(itemStack, item)) continue;
            totalAmount += item.amount;
            
        }
        return totalAmount;
    }

    /**
     * Remove a specified amount of items from the player's inventory that match the given item stack.
     * 
     * @param {Player} player - The player whose inventory is to be modified.
     * @param {ItemStack} itemStack - The item stack to match and remove from the inventory.
     * @param {number} amount - The amount of the item stack to remove.
     * @returns {boolean} True if the removal was completely successful, otherwise false.
     */
    static removeItemStacks(player, itemStack, amount) {
        let { container, inventorySize: length } = player.getComponent(EntityComponentTypes.Inventory);
        let remainingAmount = amount;

        for (let i = 0; i < length && remainingAmount > 0; i++) {
            let item = container.getItem(i);
            if (!item) continue;

            if (ItemUtils.compareItemStacks(itemStack, item)) {
                if (item.amount > remainingAmount) {
                    item.amount -= remainingAmount;
                    remainingAmount = 0;
                    container.setItem(i, item);
                } else {
                    remainingAmount -= item.amount;
                    container.setItem(i, null);
                }
            }
        }

        return remainingAmount === 0;
    }

    /**
     * Remove main hand item/s
     * @param {Player} player 
     */
    static removeMainhandItem(player){
        const slot = player?.getComponent(EntityComponentTypes.Equippable)?.getEquipmentSlot(EquipmentSlot.Mainhand);
        slot.setItem(null)

    }

    /**
     * Checks if an itemstack is not null or undifiend
     * @param {ItemStack} itemStack - The item stack to check
     * @returns {boolean} True if the itemstack is valid, otherwise false.
     */
    static isValidItemStack(itemStack){
        return itemStack == null || itemStack == undefined
    }

     /**
     * Gets the display name of an item stack. If the item is a cash item,
     * returns the cash value + Cash. Otherwise, formats the typeId into a readable string.
     * @param {ItemStack} itemStack - The item stack to get the name of.
     * @returns {string} The display name of the item.
     */
    static getItemName(itemStack) {
        const typeId = itemStack.typeId;
        
        if(itemStack.nameTag != undefined) return itemStack.nameTag;
        
        if (CashUtils.isCashItem(typeId)) return `${CashUtils.getCashItemValue(typeId)} Cash`;

        const parts = typeId.split(':');
        const subString = parts.length > 1 ? parts[1] : parts[0];

        // Split by `_` or `-`, capitalize each part, and join with a space
        const formattedName = subString.split(/[_-]/).map(word => {
            return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
        }).join(' ');

        return formattedName;
    }

    /**
     * Compares two ItemStacks to determine if they match exactly.
     * @param {ItemStack} itemStack The first ItemStack to compare.
     * @param {ItemStack} otherItemStack The second ItemStack to compare against.
     * @param {boolean} [compareAmount=false] Whether to compare the amount of items.
     * @returns {boolean} True if the ItemStacks match exactly, otherwise false.
     */
    static compareItemStacks(itemStack, otherItemStack, compareAmount = false){     
        //ID and Name
        if(itemStack.typeId !== otherItemStack.typeId) return false;
        if(itemStack.nameTag !== otherItemStack.nameTag) return false;
        if(compareAmount){
            if (itemStack.amount !== otherItemStack.amount) return false;
        } else {
            //Check if they can simply stack
            if(itemStack.isStackable) return itemStack.isStackableWith(otherItemStack);
        }

        //Item Other NBT
        if (itemStack.keepOnDeath !== otherItemStack.keepOnDeath) return false;
        if (itemStack.lockMode !== otherItemStack.lockMode) return false;

        //Lore
        const itemStackLore = itemStack.getLore();
        const otherItemStackLore = otherItemStack.getLore();
        if (itemStackLore.length !== otherItemStackLore.length ||
            !itemStackLore.every((e, i) => e === otherItemStackLore[i])) return false;

        //Item Tags
        const itemStackTags = itemStack.getTags();
        const otherItemStackTags = otherItemStack.getTags();
        if (itemStackTags.length !== otherItemStackTags.length) return false;
        if (itemStackTags.length !== otherItemStackTags.length ||
            !itemStackTags.every((e, i) => e === otherItemStackTags[i])) return false;

        //Components
        const itemStackComponents = itemStack.getComponents();
        const otherItemStackComponents = otherItemStack.getComponents();
        if (itemStackComponents.length !== otherItemStackComponents.length) return false;
        for (let i = 0; i < itemStackComponents.length; i++) {
            const component = itemStackComponents[i];
            const otherComponent = otherItemStackComponents[i];
            if(component == undefined || otherComponent == undefined) continue;
            switch (component.typeId) {
                case "minecraft:cooldown":
                    if(component.cooldownCategory !== otherComponent.cooldownCategory) return false;
                    if(component.cooldownTicks !== otherComponent.cooldownTicks) return false;
                    break;
                case "minecraft:durability":
                    if(component.damage !== otherComponent.damage) return false;
                    if(component.maxDurability !== otherComponent.maxDurability) return false;
                    break;
                case "minecraft:enchantable":
                    const enchants = component.getEnchantments();
                    const otherEnchants = otherComponent.getEnchantments();
                    if (enchants.length !== otherEnchants.length) return false;
                    if(enchants.length > 0){
                        for (let i = 0; i < enchants.length; i++) {
                            if (enchants[i].type !== otherEnchants[i].type) return false;
                            if (enchants[i].level !== otherEnchants[i].level) return false;
                        }
                    }
                    break;
                case "minecraft:food":
                    if(component.canAlwaysEat !== otherComponent.canAlwaysEat) return false;
                    if(component.nutrition !== otherComponent.nutrition) return false;
                    if(component.saturationModifier !== otherComponent.saturationModifier) return false;
                    if(component.usingConvertsTo !== otherComponent.usingConvertsTo) return false;
                    break;
                case "minecraft:potion":
                    if(component.potionEffectType.id !== otherComponent.potionEffectType.id) return false;
                    if(component.potionLiquidType.id !== otherComponent.potionLiquidType.id) return false;
                    if(component.potionModifierType.id !== otherComponent.potionModifierType.id) return false;
                    break;
            }
        }

        //Dynamic Properties
        const itemStackDPs = itemStack.getDynamicPropertyIds();
        const otherItemStackDPs = otherItemStack.getDynamicPropertyIds();
        if (itemStackDPs.length !== otherItemStackDPs.length) return false;

        for (const id of itemStackDPs) {
            const prop1 = itemStack.getDynamicProperty(id);
            const prop2 = otherItemStack.getDynamicProperty(id);
            if (typeof prop1 !== typeof prop2) return false;

            if (typeof prop1 === 'object' && prop1 !== undefined) return prop1.x == prop2.x && prop1.y == prop2.y && prop1.z == prop2.z;
            
            if (prop1 !== prop2) return false;
        }
        return true;
    }
}
